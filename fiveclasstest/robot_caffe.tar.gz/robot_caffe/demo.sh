../../build/examples/cpp_classification/classification.bin deploy.prototxt mycaffe_iter_1000.caffemodel mean.binaryproto words.txt data/re/test/313.jpg
